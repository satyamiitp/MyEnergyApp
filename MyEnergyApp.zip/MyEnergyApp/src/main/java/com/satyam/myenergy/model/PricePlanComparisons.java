package com.satyam.myenergy.model;

import java.math.BigDecimal;

public class PricePlanComparisons {
	
	private BigDecimal plan_price;
	
	public PricePlanComparisons()
	{
		
	}

	public BigDecimal getPlan_price() {
		return plan_price;
	}

	public void setPlan_price(BigDecimal plan_price) {
		this.plan_price = plan_price;
	}

}	
